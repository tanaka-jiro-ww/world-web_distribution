/**
 * Twitter Classic Restorer - content.js (Legal Content Protection Enhanced)
 */

const twitterBirdPath = "M23.643 4.937c-.835.37-1.732.62-2.675.733.962-.576 1.7-1.49 2.048-2.578-.9.534-1.897.922-2.958 1.13-.85-.904-2.06-1.47-3.4-1.47-2.572 0-4.658 2.086-4.658 4.66 0 .364.042.718.12 1.06-3.873-.195-7.304-2.05-9.602-4.868-.4.69-.63 1.49-.63 2.342 0 1.616.823 3.043 2.072 3.878-.764-.025-1.482-.234-2.11-.583v.06c0 2.257 1.605 4.14 3.737 4.568-.392.106-.803.162-1.227.162-.3 0-.593-.028-.877-.082.593 1.85 2.313 3.198 4.352 3.237-1.594 1.25-3.607 1.995-5.792 1.995-.375 0-.744-.022-1.107-.065 2.062 1.323 4.51 2.093 7.14 2.093 8.57 0 13.255-7.098 13.255-13.254 0-.2-.005-.402-.014-.602.91-.658 1.7-1.477 2.323-2.41z";
const twitterColor = "rgb(29, 155, 240)"; 
const faviconUrl = "https://abs.twimg.com/favicons/twitter.2.ico";

const xLogoD = [
    "M714.163 519.284",
    "M21.742 21.75", 
    "M18.244", "M14.258", "M1.25", "M17.838", "M1 2L23 22"
];

let isProcessing = false;

// 現在のURLが規約ページやヘルプセンターかどうかを判定
const isLegalPage = () => {
    const path = window.location.href;
    return path.includes('rules.x.com') || path.includes('/rules') || path.includes('/tos') || path.includes('/privacy') || path.includes('help.x.com');
};

const injectStyles = () => {
    if (document.getElementById('twitter-classic-styles')) return;
    const style = document.createElement('style');
    style.id = 'twitter-classic-styles';
    style.innerHTML = `
        input[placeholder*="X"]::placeholder { color: transparent !important; }
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif !important; }
    `;
    document.head.appendChild(style);
};

const restoreHeadMetadata = () => {
    const rels = ['icon', 'shortcut icon', 'apple-touch-icon'];
    rels.forEach(rel => {
        const icons = document.querySelectorAll(`link[rel*="${rel}"]`);
        icons.forEach(icon => { if (icon.href !== faviconUrl) icon.href = faviconUrl; });
    });
    // タイトルは置換（規約ページでもタブはTwitter表記で良いため）
    if (document.title.includes('X')) document.title = document.title.replace(/X/g, 'Twitter');
};

const handleLogos = () => {
    const svgs = document.querySelectorAll('svg');
    svgs.forEach(svg => {
        if (svg.querySelector(`path[d="${twitterBirdPath}"]`)) return;

        const label = (svg.getAttribute('aria-label') || svg.closest('a')?.getAttribute('aria-label') || "").toLowerCase();
        const className = svg.getAttribute('class') || "";
        
        if (label.includes('apple') || label.includes('grok') || label.includes('google')) return;

        const paths = svg.querySelectorAll('path');
        const fullD = Array.from(paths).map(p => p.getAttribute('d')).join(" ");
        
        let isX = (
            label === 'x' || 
            xLogoD.some(d => fullD.includes(d)) || 
            svg.closest('h1 a') || 
            svg.closest('#placeholder') ||
            className.includes('icon-home') ||
            className.includes('u01b__icon-home')
        );

        if (isX) {
            svg.innerHTML = `<path d="${twitterBirdPath}"></path>`;
            svg.setAttribute('viewBox', '0 0 24 24');
            svg.style.color = twitterColor;
            svg.style.fill = twitterColor;
            
            if (className.includes('u01b__icon-home')) {
                svg.style.width = "2em"; 
                svg.style.height = "2em";
            } else {
                svg.style.width = ""; 
                svg.style.height = "";
            }
        }
    });
};

const restoreTwitter = () => {
    if (isProcessing) return;
    isProcessing = true;

    try {
        const legalPage = isLegalPage();

        const walking = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
            acceptNode: (node) => {
                const parent = node.parentElement;
                
                // 1. ツイート本文は常に保護
                if (parent?.closest('[data-testid="tweetText"]')) return NodeFilter.FILTER_REJECT;
                
                // 2. 規約ページ・ヘルプページの場合、特定のUI（ボタンやタブ）以外はすべて保護
                if (legalPage) {
                    // サイドバーやヘッダーのナビゲーション以外の「メインコンテンツ」と思われる場所をスキップ
                    if (parent?.closest('article, .u01b__article-content, .help-center-content, .column, main p, main span')) {
                        // ただしボタンのテキストなどは置換したい場合があるが、安全のため本文らしき場所は全スキップ
                        return NodeFilter.FILTER_REJECT;
                    }
                }

                // 3. コピーライト保護
                if (node.textContent.includes('X Corp.')) return NodeFilter.FILTER_REJECT;

                return NodeFilter.FILTER_ACCEPT;
            }
        });

        let node;
        while (node = walking.nextNode()) {
            const original = node.textContent;
            const replaced = original
                .replace(/X/g, (match, offset, string) => {
                    const prev = string[offset - 1];
                    const next = string[offset + 1];
                    const isStandalone = (!prev || /[^a-zA-Z0-9]/.test(prev)) && (!next || /[^a-zA-Z0-9]/.test(next));
                    return isStandalone ? 'Twitter' : match;
                })
                .replace(/ポストする/g, 'ツイートする')
                .replace(/ポスト/g, 'ツイート')
                .replace(/リポスト/g, 'リツイート');
            if (original !== replaced) node.textContent = replaced;
        }

        handleLogos();

        const searchInput = document.querySelector('input[data-testid="SearchBox_Search_Input"]');
        if (searchInput && searchInput.placeholder.includes('X')) searchInput.placeholder = 'Twitterを検索';

        document.querySelectorAll('[data-testid*="TweetButton"], [data-testid="addButton"], [data-testid="loginButton"]').forEach(btn => {
            if (btn.style.backgroundColor !== twitterColor) {
                btn.style.backgroundColor = twitterColor;
                btn.style.borderColor = "transparent";
                const span = btn.querySelector('span');
                if (span) span.style.color = "#ffffff";
            }
        });

        restoreHeadMetadata();
        injectStyles();

    } catch (e) {
    } finally {
        isProcessing = false;
    }
};

const observer = new MutationObserver(restoreTwitter);
observer.observe(document.body, { childList: true, subtree: true });
if (document.querySelector('head')) {
    observer.observe(document.querySelector('head'), { childList: true, subtree: true, characterData: true });
}

restoreTwitter();